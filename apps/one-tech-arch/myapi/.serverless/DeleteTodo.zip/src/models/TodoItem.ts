export interface TodoItem {
  id: string;
  name: string;
  done: boolean;
  createdAt: string;
}
